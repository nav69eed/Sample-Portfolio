---
name: Laravel 9 Updates
about: Inform about Laravel 9 changes
title: ''
labels: ''
assignees: ''

---

<!--
NOTE: Laravel has incorporated this package into the core of Laravel as of Laravel 9.

Do not use this package in Laravel 9. Details here: https://github.com/fideloper/TrustedProxy/issues/152
-->
